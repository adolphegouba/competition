# Dictionnaire des variables — données propres DGESS (étape 2)

| Variable | Type | Valeurs possibles | Description |
|---|---|---|---|
| `cycle` | texte | prescolaire, primaire | Cycle d'enseignement |
| `indicateur` | texte | effectif, nouveaux_inscrits_cp1, nb_ecoles, tba, tbs, tbps, taux_achevement, taux_reussite_cep, ips_tba, ips_tbs, ips_tap… | Indicateur mesuré, déduit du titre du tableau |
| `region` | texte | 13 anciennes régions, ou vide | Région ; vide quand le tableau est national |
| `statut` | texte | Public, Prive, Communautaire, ou vide | Statut de l'établissement |
| `milieu` | texte | Urbain, Rural, ou vide | Milieu de résidence |
| `classe` | texte | CP1 à CM2, Petite, Moyenne, Grande section, ou vide | Niveau d'étude |
| `sexe` | texte | G, F, T | Garçons, filles, total |
| `annee_scolaire` | texte | 2015-2016 à 2024-2025 | Année scolaire ; pour le CEP, session de fin d'année |
| `valeur` | nombre | — | Effectif ou nombre (unités), taux (%), indice de parité (rapport filles/garçons) |
| `niveau_geo` | texte | regional, national | Niveau géographique de la valeur |
| `source_feuille` | texte | — | Feuille du classeur d'origine |
| `source_tableau` | texte | — | Numéro du tableau dans la feuille |
| `ligne_source` | entier | — | Ligne du classeur d'origine, pour retrouver la valeur |
| `dims_totalisees` | texte | region, statut… | (fichier des totaux) dimensions agrégées sur cette ligne |

Sigles : TBA = taux brut d'admission ; TBS = taux brut de scolarisation ; TBPS = taux brut de préscolarisation ;
TAP = taux d'achèvement du primaire ; IPS = indice de parité entre les sexes ; CEP = certificat d'études primaires.
