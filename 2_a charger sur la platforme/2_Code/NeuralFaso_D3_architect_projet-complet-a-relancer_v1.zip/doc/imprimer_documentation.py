"""Imprime doc/documentation.html en PDF A4 avec Chrome ou Edge.

Lancement :  python doc/imprimer_documentation.py
Sortie :     doc/NeuralFaso_D3_documentation_v1.pdf
"""
import pathlib
import subprocess

ICI = pathlib.Path(__file__).resolve().parent
SOURCE = ICI / "documentation.html"
SORTIE = ICI / "NeuralFaso_D3_documentation_v1.pdf"
NAVIGATEURS = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
               r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
               r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
               r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"]

nav = next((p for p in NAVIGATEURS if pathlib.Path(p).exists()), None)
if not nav:
    raise SystemExit("Chrome ou Edge introuvable : ouvrez documentation.html et imprimez-le en PDF.")
subprocess.run([nav, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--virtual-time-budget=5000",
                f"--print-to-pdf={SORTIE}", SOURCE.as_uri()], check=True, capture_output=True, timeout=180)
print(f"PDF écrit : {SORTIE.name} ({SORTIE.stat().st_size // 1024} Ko)")
