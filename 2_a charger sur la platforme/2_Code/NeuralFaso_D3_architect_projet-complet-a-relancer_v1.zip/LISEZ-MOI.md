# Data Challenge Burkina 2026, défi 3 : répartir les salles de classe et les enseignants du primaire

Équipe NeuralFaso

La documentation complète (15 pages, plan du challenge) est dans `NeuralFaso_D3_documentation_v1.pdf`.

## L'équipe

Nous sommes deux. Chacun porte deux des quatre rôles du challenge et a vérifié le travail de l'autre.

| Membre | Rôles | Ce qu'il a fait |
|---|---|---|
| Membre 1 | Data Engineer et Data Architect | Collecte des sources (fichier DGESS, annuaires 2017-2018 et 2024-2025, projections INSD, rapport ESU, limites administratives, écoles OpenStreetMap, population WorldPop). Nettoyage et contrôles (étapes 2 à 2d). Panel régional, fond de carte, correspondance avec le découpage 2025, carte des écoles (étapes 3 à 3c). Script `lancer_tout.ps1`. |
| Membre 2 | Data Scientist et Data Analyst | Besoins en 2030 et scénarios, indice de priorité, types d'action, répartition optimisée, redéploiement, test de robustesse, résultats dans le découpage 2025 (étapes 4 et 4b). Vérification des résultats avec les chiffres publiés. Application et note au décideur (étapes 5 et 5b). |

Les hypothèses (norme, scénarios, seuils) ont été choisies ensemble.

## En bref

D'ici 2030, si la scolarisation reste à son niveau actuel, il manquera 9 514 enseignants et 11 070 salles de classe au primaire,
avec la norme nationale de 50 élèves par maître. Les besoins les plus urgents sont au Sahel et à l'Est. Dans 10 provinces,
moins de 40 % des enfants vont à l'école : il faut d'abord y rouvrir et sécuriser les écoles.

À budget égal (la moitié du déficit, soit 4 757 enseignants), une répartition qui va d'abord aux provinces les plus chargées
ramène la pire situation de 97 à 57 élèves par maître. Avec une répartition proportionnelle au nombre d'élèves,
12 provinces restent au-delà de 60 élèves par maître ; avec la nôtre, aucune.

## Nos choix

Nous avons d'abord travaillé avec une norme de 40 élèves par maître, que nous pensions tirée du PSEF. En comparant nos
résultats avec les chiffres publiés, nous avons vu que les tableaux de bord de la DGESS parlent d'une norme nationale de 50.
Nous sommes passés à 50. Le classement des provinces ne change pas, mais les volumes baissent beaucoup (26 859 enseignants
manquants avec 40, 9 514 avec 50). Nous gardons 40 comme scénario « qualité ».

Pour le taux de scolarisation, nous avons rapporté l'année 2024-2025 à la population de 2024. Nous avons testé 2024, 2025 et
la moyenne des deux : seule la population de 2024 redonne exactement les taux publiés par la DGESS dans les 13 régions.
C'est donc la convention du ministère.

Nous n'avons pas utilisé de machine learning. Nous n'avons que deux années de données par province, et la crise a cassé
les tendances depuis 2019. Le calcul (enfants de 6-11 ans × taux de scolarisation ÷ norme) se vérifie à la main, ce qui compte
pour un décideur.

L'annuaire 2017-2018 nous a servi de point de comparaison avant la crise. Il a fallu adapter l'extraction : les tableaux
n'ont pas les mêmes numéros d'une année à l'autre, et en 2017-2018 le tableau I.1 ne couvre que 43 communes. Nous repérons
maintenant chaque tableau par son titre.

L'indice de priorité donne le même poids aux 8 critères. Comme ce choix se discute, nous avons tiré 10 000 jeux de poids au
hasard : les 10 provinces de tête y restent dans au moins la moitié des cas, et Séno, Tapoa et Yagha dans plus de 90 %.

Pour la carte des écoles, OpenStreetMap comptait 11 673 « écoles », mais beaucoup étaient des bâtiments d'une même école.
Une fois regroupées, il reste 4 905 écoles, soit environ une sur trois. Nous n'avons donc pas présenté les zones éloignées
d'une école comme des sites où construire, mais comme des pistes à vérifier sur le terrain. L'état des salles et les
fermetures ne sont publiés que par province : la carte les montre à ce niveau.

## Relancer le travail

1. Installer Python 3.10 ou plus récent, puis `pip install -r requirements.txt`.
2. Placer les données dans `data/01_collecte/`, sans les renommer :
   - le fichier des organisateurs `DONNEES_STATISTQUES_ PRESCOLAIRE ET PRIMAIRE_2016_2025_DCB.xlsx` ;
   - dans `annuaires/` : les CSV CNS530 (2024-2025) et CNS521 (2017-2018) du Data Pack. D'autres années peuvent être ajoutées ;
   - dans `projections/` : `NADA276_RGPH2019_Projections_2020-2035.csv` ;
   - dans `esu/` : le CSV du rapport ESU de février 2026 ;
   - dans `cartographie/` : `bfa_admin2.geojson` (HDX, jeu « cod-ab-bfa »), `hotosm_bfa_education_facilities_osm_geojson.zip`
     (HDX, jeu « hotosm_bfa_education_facilities ») et `bfa_ppp_2020_1km_UNadj_ASCII_XYZ.zip` (WorldPop).
3. Lancer `.\lancer_tout.ps1` dans PowerShell, depuis le dossier du projet. Le script lance les étapes dans l'ordre :
   1, 2, 2b, 2c, 3, 3b, 2d, 3c, 4, 4b, 5, 5b. Il ouvre ensuite l'application et la note.
4. L'application est une seule page HTML : elle s'ouvre d'un double-clic. Le fond de la carte des écoles a besoin d'Internet ;
   sans connexion, les écoles, les zones et les provinces restent visibles.

## Code déposé sur la plateforme

Dans la rubrique Code, chaque script est déposé en clair sous un nom conforme à la nomenclature. Pour relancer,
utilisez l'archive `NeuralFaso_D3_architect_projet-complet-a-relancer_v1.zip`, qui garde les noms d'origine
(les scripts s'importent entre eux par ces noms).

| Fichier déposé | Nom d'origine (`src/`) |
|---|---|
| `NeuralFaso_01-collecte_D3_engineer_inventaire-sources_v1.py` | `etape01_inventaire_sources.py` |
| `NeuralFaso_02-nettoyage_D3_engineer_nettoyage-dgess_v1.py` | `etape02_nettoyage_dgess.py` |
| `NeuralFaso_02-nettoyage_D3_engineer_extraction-annuaires_v1.py` | `etape02b_extraction_annuaires.py` |
| `NeuralFaso_02-nettoyage_D3_engineer_projections-population_v1.py` | `etape02c_projections_population.py` |
| `NeuralFaso_02-nettoyage_D3_engineer_extraction-esu_v1.py` | `etape02d_extraction_esu.py` |
| `NeuralFaso_03-transformation_D3_analyst_panel-region-ratios_v1.py` | `etape03_transformation.py` |
| `NeuralFaso_03-transformation_D3_architect_fond-de-carte_v1.py` | `etape03b_fond_de_carte.py` |
| `NeuralFaso_03-transformation_D3_architect_ecoles-accessibilite_v1.py` | `etape03c_ecoles_accessibilite.py` |
| `NeuralFaso_04-analyse_D3_scientist_besoins-priorites-allocation_v1.py` | `etape04_besoins_allocation.py` |
| `NeuralFaso_04-analyse_D3_scientist_redeploiement-robustesse-decoupage_v1.py` | `etape04b_redeploiement_robustesse_decoupage.py` |
| `NeuralFaso_05-interpretation_D3_analyst_application-aide-decision_v1.py` | `etape05_application.py` |
| `NeuralFaso_05-interpretation_D3_analyst_note-decideur_v1.py` | `etape05b_note_decideur.py` |

## Ce que contient chaque dossier

Tous les fichiers suivent le modèle `EQUIPE_ETAPE_DEFI_ROLE_description_vN`, avec `NeuralFaso` comme nom d'équipe
(par exemple `NeuralFaso_04-analyse_D3_scientist_besoins-2030-priorites-province_v1.csv`). Chaque étape écrit un journal
(`journal-…md`) avec les règles appliquées et le résultat des contrôles.

| Dossier | Fichiers principaux |
|---|---|
| `data/01_collecte` | Données brutes, telles que reçues, et leur inventaire (producteur, publication, année, lien) |
| `data/02_nettoyage` | Fichier DGESS en format long, lignes de total et anomalies ; tableaux des annuaires par province (écoles, salles, maîtres, élèves, distance à l'école, état des salles) ; population 2020-2035 ; élèves déplacés et écoles rouvertes (ESU) |
| `data/03_transformation` | Panel région × année avec ses ratios et son dictionnaire ; fond de carte allégé ; correspondance avec le découpage 2025 ; écoles OpenStreetMap, enfants par maille de 5 km, accessibilité par province |
| `data/04_analyse` | Besoins 2030 par province (3 scénarios, norme 50 et 40), indice de priorité, répartition optimisée et proportionnelle, redéploiement, robustesse de l'indice, résultats par province et région 2025, zones peuplées sans école sur la carte |
| `data/05_interpretation` | Application d'aide à la décision et note d'une page (HTML et PDF) |
| `src` | Un script par étape, `config.py` et `referentiels.py` |
| `doc` | Documentation de 15 pages (source HTML, PDF, script d'impression), dictionnaire des variables du nettoyage |

Quelques résultats des journaux :
- Toutes les sommes de contrôle (provinces = région, public + privé = total, garçons + filles = total) tombent juste.
- De 2017-2018 à 2024-2025, le pays est passé de 15 756 à 14 276 écoles. Tapoa, Soum et Yagha ont perdu près de 80 % de leurs élèves.
- Si chaque province retrouvait son taux de scolarisation de 2017-2018, il faudrait accueillir 670 000 élèves de plus en 2030,
  soit 13 008 enseignants et 13 188 salles de plus.
- Les provinces bien dotées peuvent céder 1 048 enseignants sans dépasser 50 élèves par maître, soit 11 % du déficit.
- En 2024-2025, on compte 1,04 classe par salle. Si cette double vacation continue, le déficit de salles baisse de 24 %.

## Sources

- DGESS, données statistiques du préscolaire et du primaire 2015-2016 à 2024-2025 (fichier des organisateurs).
- DGESS/MEBAPLN, Annuaire statistique de l'enseignement primaire 2024-2025 (CNS530) et DGESS/MENA, annuaire 2017-2018 (CNS521), Data Pack.
- INSD, RGPH 2019, volume 4 : projections démographiques 2020-2035 (NADA276), Data Pack.
- DGESS, rapport statistique mensuel de l'éducation en situation d'urgence, février 2026, Data Pack.
- IGB et OCHA, limites administratives COD-AB du Burkina Faso (2025).
- DGESS/MEBAPLN, tableaux de bord de l'enseignement primaire 2016-2017 et 2023-2024 : norme nationale de 50 élèves par enseignant.
- MENA, Plan sectoriel de l'éducation et de la formation 2017-2030 : une classe par salle.
- OpenStreetMap, écoles du Burkina Faso (export Humanitarian OpenStreetMap Team sur HDX, novembre 2026), licence ODbL.
- WorldPop, population 2020 sur une grille de 1 km.

## Usage de l'intelligence artificielle

Nous avons utilisé un assistant d'IA (Claude) pour écrire une partie du code Python et de l'application. Les choix de
méthode, les hypothèses et la vérification des chiffres sont de l'équipe : chaque résultat a été contrôlé par les sommes
de contrôle et comparé aux publications d'origine.
