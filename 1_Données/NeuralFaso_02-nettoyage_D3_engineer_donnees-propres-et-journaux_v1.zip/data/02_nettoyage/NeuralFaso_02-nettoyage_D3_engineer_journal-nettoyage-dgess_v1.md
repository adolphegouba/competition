# Journal de nettoyage — fichier DGESS préscolaire et primaire 2016-2025
Exécuté le 17/11/2026 à 20:58. Fichier source : `DONNEES_STATISTQUES_ PRESCOLAIRE ET PRIMAIRE_2016_2025_DCB.xlsx`

## Tableaux lus
- PRESCOLAIRE / Tableau 1 : « Tableau 1 : Évolution des effectifs du préscolaire de 2015/2016 à 2024/2025 par sexe et par région » → indicateur `effectif`, 420 valeurs, colonnes G/F/T, dimensions ['region']
- PRESCOLAIRE / Tableau 2 : « Tableau 2: Évolution des effectifs du préscolaire de 2015/2016 à 2024/2025 par sexe et par statut » → indicateur `effectif`, 120 valeurs, colonnes G/F/T, dimensions ['statut']
- PRESCOLAIRE / Tableau 3 : « Tableau 3: Évolution des effectifs du préscolaire de 2015/2016 à 2024/2025 par sexe et par milieu » → indicateur `effectif`, 81 valeurs, colonnes G/F/T, dimensions ['milieu']
- PRESCOLAIRE / Tableau 4 : « Tableau 4: Évolution des effectifs du préscolaire de 2015/2016 à 2024/2025 par niveau, sexe et par statut » → indicateur `effectif`, 390 valeurs, colonnes G/F/T, dimensions ['statut', 'classe']
- PRESCOLAIRE / Tableau 5 : « Tableau 5: Évolution du TBS au préscolaire de 2015/2016 à 2024/2025 par sexe et par région » → indicateur `tbs`, 420 valeurs, colonnes G/F/T, dimensions ['region']
- PRESCOLAIRE / Tableau 6 : « Tableau 6: Évolution de l’IPS du TBS au préscolaire de 2015/2016 à 2024/2025 par région » → indicateur `ips_tbs`, 140 valeurs, colonne sexe ou sans sexe, dimensions ['region']
- PRESCOLAIRE / Tableau 7 : « Tableau 7 : Évolution du nombre de structures éducatives du préscolaire de 2015/2016 à 2024/2025 par statut et » → indicateur `nb_ecoles`, 530 valeurs, colonne sexe ou sans sexe, dimensions ['region', 'statut']
- PRESCOLAIRE / Tableau 8 : « Tableau 8 : Évolution du nombre de salles de classes du préscolaire de 2015/2016 à 2024/2025 par statut et par » → indicateur `nb_salles`, 530 valeurs, colonne sexe ou sans sexe, dimensions ['region', 'statut']
- Feuil1 / Tableau 1 : « Tableau 1 : Évolution des effectifs du primaire de 2015/2016 à 2024/2025 par sexe et par région » → indicateur `effectif`, 420 valeurs, colonne sexe ou sans sexe, dimensions ['region', 'sexe']
- Feuil2 / Tableau 2 : « Tableau 2: Évolution des effectifs du primaire de 2015/2016 à 2024/2025 par sexe et par statut » → indicateur `effectif`, 90 valeurs, colonne sexe ou sans sexe, dimensions ['statut', 'sexe']
- Feuil3 / Tableau 3 : « Tableau 3: Évolution des effectifs du primaire de 2015/2016 à 2024/2025 par sexe et par milieu » → indicateur `effectif`, 90 valeurs, colonne sexe ou sans sexe, dimensions ['milieu', 'sexe']
- Feuil4 / Tableau 4 : « Tableau 4: Évolution des effectifs du primaire de 2015/2016 à 2024/2025 par niveau, sexe et par statut » → indicateur `effectif`, 450 valeurs, colonne sexe ou sans sexe, dimensions ['statut', 'classe', 'sexe']
- Feuil5 / Tableau 5 : « Tableau 5: Évolution des nouveaux inscrits au CP1 de 2015/2016 à 2024/2025 par sexe et par région » → indicateur `nouveaux_inscrits_cp1`, 420 valeurs, colonne sexe ou sans sexe, dimensions ['region', 'sexe']
- Feuil6 / Tableau 6 : « Tableau 6: Évolution du TBA au primaire de 2015/2016 à 2024/2025 par sexe et par région » → indicateur `tba`, 420 valeurs, colonnes G/F/T, dimensions ['region']
- Feuil7 / Tableau 7 : « Tableau 7: Évolution du TBS au primaire de 2015/2016 à 2024/2025 par sexe et par région » → indicateur `tbs`, 420 valeurs, colonnes G/F/T, dimensions ['region']
- Feuil8 / Tableau 8 : « Tableau 8: Évolution du Taux d’Achèvement au primaire de 2015/2016 à 2024/2025 par sexe et par région » → indicateur `taux_achevement`, 420 valeurs, colonnes G/F/T, dimensions ['region']
- Feuil9 / Tableau 9 : « Tableau 9: Évolution du taux de réussite au CEP de 2015 à 2025 par sexe et par région » → indicateur `taux_reussite_cep`, 420 valeurs, colonne sexe ou sans sexe, dimensions ['region', 'sexe']
- Feuil10 / Tableau 10 : « Tableau 10: Évolution de l’IPS du TBA au primaire de 2015/2016 à 2024/2025 par région » → indicateur `ips_tba`, 140 valeurs, colonne sexe ou sans sexe, dimensions ['region']
- Feuil11 / Tableau 11 : « Tableau 11: Évolution de l’IPS du TBS au primaire de 2015/2016 à 2024/2025 par région » → indicateur `ips_tbs`, 140 valeurs, colonne sexe ou sans sexe, dimensions ['region']
- Feuil12 / Tableau 12 : « Tableau 12: Évolution de l’IPS du TAP de 2015/2016 à 2024/2025 par région » → indicateur `ips_tap`, 140 valeurs, colonne sexe ou sans sexe, dimensions ['region']
- Feuil13 / Tableau 13 : « Tableau 13 : Évolution du nombre d’écoles primaires de 2015/2016 à 2024/2025 par statut et par région » → indicateur `nb_ecoles`, 420 valeurs, colonne sexe ou sans sexe, dimensions ['region', 'statut']

## Contrôles
| Contrôle | Comparaisons | Écarts |
|---|---|---|
| G + F = T | 827 | 0 |
| somme des regions = total | 140 | 0 |
| somme des statuts = total | 520 | 0 |
| somme des milieus = total | 54 | 0 |
| somme des classes = total | 150 | 0 |
| tba dans [0 ; 250] | 420 | 0 |
| tbs dans [0 ; 250] | 840 | 0 |
| taux_achevement dans [0 ; 250] | 420 | 0 |
| taux_reussite_cep dans [0 ; 100] | 420 | 0 |
| ips_tba dans [0.3 ; 2] | 140 | 0 |
| ips_tbs dans [0.3 ; 2] | 280 | 0 |
| ips_tap dans [0.3 ; 2] | 140 | 0 |
| ruptures ≥ 30 % signalées (information) | 3107 | 575 |

## Règles appliquées
- Format long : une ligne par indicateur, catégorie, sexe et année scolaire.
- Années notées `AAAA-AAAA` (année scolaire). Une année seule (ex. 2016) est lue comme l'année de fin : 2016 → 2015-2016 ; pour le CEP, c'est la session de fin d'année.
- Régions : 13 anciennes régions, libellés harmonisés (ex. HAUT-BASSINS → HAUTS-BASSINS). « NATIONAL », « Burkina Faso » et « Total général » sont traités comme des totaux.
- Sexe : G (garçons), F (filles), T (total).
- Les lignes de total sont retirées des données détaillées et conservées à part pour les contrôles.
- La nature de chaque colonne est déduite de ses valeurs, et non de son en-tête (un en-tête « REGION » contenant Urbain/Rural est reclassé en milieu).
- Seule l'année est conservée dans les en-têtes contenant du texte supplémentaire.

## Résultat
- 5577 valeurs détaillées, 1044 valeurs de total.
- 580 remarques consignées dans le fichier des anomalies.
  - cellule_texte_long_ignoree : 1
  - en-tete_texte_parasite : 3
  - en-tete_trompeur : 1
  - rupture_forte_info : 575