# Journal d'extraction — projections démographiques 2020-2035 (INSD)
Exécuté le 17/11/2026 20:58. Source : `NADA276_RGPH2019_Projections_2020-2035.csv`

- Coquilles corrigées dans le document source : 24
  - OUDALAN (province), 0 ans, 2031 : ensemble imprimé 3189, remplacé par hommes + femmes = 6301
  - OUDALAN (province), 1-4 ans, 2031 : ensemble imprimé 12276, remplacé par hommes + femmes = 24063
  - OUDALAN (province), 10-14 ans, 2031 : ensemble imprimé 12684, remplacé par hommes + femmes = 26382
  - OUDALAN (province), 12-15 ans, 2031 : ensemble imprimé 9453, remplacé par hommes + femmes = 20518
  - OUDALAN (province), 15-19 ans, 2031 : ensemble imprimé 10754, remplacé par hommes + femmes = 22951
  - OUDALAN (province), 16-18 ans, 2031 : ensemble imprimé 6478, remplacé par hommes + femmes = 13719
  - OUDALAN (province), 20-24 ans, 2031 : ensemble imprimé 9158, remplacé par hommes + femmes = 19076
  - OUDALAN (province), 25-29 ans, 2031 : ensemble imprimé 6977, remplacé par hommes + femmes = 15144
  - OUDALAN (province), 3-5 ans, 2031 : ensemble imprimé 9025, remplacé par hommes + femmes = 17696
  - OUDALAN (province), 30-34 ans, 2031 : ensemble imprimé 4851, remplacé par hommes + femmes = 11341
  - OUDALAN (province), 35-39 ans, 2031 : ensemble imprimé 4307, remplacé par hommes + femmes = 9170
  - OUDALAN (province), 40-44 ans, 2031 : ensemble imprimé 3836, remplacé par hommes + femmes = 8395
  - OUDALAN (province), 45-49 ans, 2031 : ensemble imprimé 3264, remplacé par hommes + femmes = 6658
  - OUDALAN (province), 5-9 ans, 2031 : ensemble imprimé 14566, remplacé par hommes + femmes = 28579
  - OUDALAN (province), 50-54 ans, 2031 : ensemble imprimé 2624, remplacé par hommes + femmes = 5495
  - OUDALAN (province), 55-59 ans, 2031 : ensemble imprimé 1983, remplacé par hommes + femmes = 3754
  - OUDALAN (province), 6-11 ans, 2031 : ensemble imprimé 17030, remplacé par hommes + femmes = 33577
  - OUDALAN (province), 60-64 ans, 2031 : ensemble imprimé 1524, remplacé par hommes + femmes = 2964
  - OUDALAN (province), 65-69 ans, 2031 : ensemble imprimé 1148, remplacé par hommes + femmes = 2075
  - OUDALAN (province), 70-74 ans, 2031 : ensemble imprimé 720, remplacé par hommes + femmes = 1449
  - OUDALAN (province), 75-79 ans, 2031 : ensemble imprimé 470, remplacé par hommes + femmes = 812
  - OUDALAN (province), 80+ ans, 2031 : ensemble imprimé 333, remplacé par hommes + femmes = 599
  - OUDALAN (province), total ans, 2031 : ensemble imprimé 94664, remplacé par hommes + femmes = 195208
  - ZONDOMA (province), total ans, 2034 : hommes/femmes illisibles (163 / 182), seul l'ensemble imprimé (346574) est gardé
- 64030 valeurs ; 45 provinces (attendu 45), 13 régions (attendu 13) ; années 2020 à 2035.

- Entités sans les 16 années pour les 6-11 ans : 0 
- Hommes + femmes = ensemble (6-11 ans) : 928 comparaisons, 0 écarts.
- Somme des provinces = région (6-11 ans, tolérance 0,5 %) : 208 comparaisons, 0 écarts ; écart maximal 0.00%.

Note : les projections suivent les 13 anciennes régions et les 45 provinces, comme les données DGESS.