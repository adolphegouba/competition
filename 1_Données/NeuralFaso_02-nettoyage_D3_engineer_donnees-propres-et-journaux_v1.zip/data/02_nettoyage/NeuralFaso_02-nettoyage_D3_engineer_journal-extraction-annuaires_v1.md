# Journal d'extraction — annuaires du primaire (DGESS)
Exécuté le 17/11/2026 20:58

| Fichier | Année | I.1 lignes | V.5 lignes | VI.4.1 lignes |
|---|---|---|---|---|
| CNS521_Annuaire_statistique_de_lenseignement_Primaire_2017_2 | 2017-2018 | 177 | 290 | 174 |
| CNS530_Annuaire_statistique_de_lenseignement_primaire_2024_2 | 2024-2025 | 177 | 290 | 174 |

## Contrôles
| Contrôle | Comparaisons | Écarts |
|---|---|---|
| I.1 somme des provinces = total région | 390 | 0 |
| I.1 public + privé = total (élèves) | 94 | 0 |
| I.1 ratio élèves/maître recalculé = publié (±0,1) | 354 | 0 |
| I.1 provinces trouvées (attendu 45) | 45 | 0 |
| VI.4.1 somme des provinces = total région | 156 | 0 |
| V.5 pourcentages qui totalisent 100 (±0,2) | 580 | 1 |

Règles : nombres « 1 039 » et « 62,6 » convertis ; lignes « Total Région » gardées pour contrôle (province = _TOTAL_REGION_) ; ratios recalculés à partir des comptages ; province rattachée à son ancienne région (13 régions, 45 provinces).
VI.4.1 : le premier bloc de pages n'a pas d'étiquette de statut dans le PDF ; il est classé « Public » d'après l'ordre de la table des matières (VI.4.1.1 Public, VI.4.1.2 Privé, VI.4.1.3 Public + privé).