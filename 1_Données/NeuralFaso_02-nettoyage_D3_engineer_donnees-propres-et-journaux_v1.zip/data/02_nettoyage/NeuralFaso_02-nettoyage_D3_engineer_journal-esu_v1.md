# Journal d'extraction — rapport ESU
Exécuté le 17/11/2026 20:58. Source : Rapport_statistique_mensuel_ESU_Fevrier_2026.csv

- Provinces de 2025 lues : 47 ; anciennes provinces couvertes : 45 sur 45.
- Totaux : EDI du primaire = 436 683 (publié : 436 683) ; structures réouvertes du primaire = 1 840 (publié : 1 840) ; délocalisées = 492 (publié : 492).
- Libellés non reconnus : aucun
- Les provinces absentes d'une annexe n'ont aucune valeur déclarée : elles sont mises à 0 à l'étape 4.
- Attention : ces données datent de février 2026 (année 2025-2026), l'annuaire de 2024-2025.