# Journal de l'étape 4b — redéploiement, robustesse, découpage 2025
Exécuté le 17/11/2026 20:58

## 1. Redéploiement des enseignants avant recrutement
Effectifs 2030 du scénario tendanciel. Une province donne ses maîtres en surplus tant qu'elle reste sous le seuil indiqué ; les maîtres libérés vont aux provinces en déficit selon la méthode optimisée (les donneuses ne reçoivent rien).

| Seuil des donneuses | Enseignants redéployables | Provinces donneuses | Part du déficit national couverte |
|---|---|---|---|
| 50 élèves par maître | 1 048 | 11 | 11,0 % |
| 55 élèves par maître | 2 381 | 18 | 25,0 % |

Avec le seuil de 50 : donneuses — BAZEGA (170), IOBA (162), PONI (134), OUBRITENGA (133), NOUMBIEL (117), KENEDOUGOU (101), LERABA (91), ZOUNDWEOGO (42), KOURWEOGO (37), ZIRO (32), BOUGOURIBA (29) ; principales bénéficiaires — SANMATENGA (+261), SENO (+179), BAM (+176), LOROUM (+161), GOURMA (+43).

Conclusion : le déficit est général. Le redéploiement est gratuit et doit venir en premier, mais il ne couvre qu'une petite part du besoin : le recrutement reste indispensable.

## 2. Robustesse de l'indice de priorité
10 000 pondérations tirées au hasard (loi de Dirichlet uniforme sur les 8 critères, graine 2026). Pour chaque province : part des tirages où elle est dans les 10 premières, et rang entre le 5e et le 95e centile.

| Province | Rang (poids égaux) | Dans le top 10 | Rang médian | Rang (5 %-95 %) |
|---|---|---|---|---|
| SENO | 1 | 98% | 2 | 1-8 |
| TAPOA | 3 | 96% | 4 | 1-10 |
| YAGHA | 2 | 93% | 3 | 1-13 |
| SOUM | 4 | 86% | 4 | 2-17 |
| GNAGNA | 8 | 86% | 8 | 4-13 |
| KOMPIENGA | 6 | 79% | 7 | 1-18 |
| GOURMA | 9 | 76% | 8 | 3-15 |
| LOROUM | 5 | 76% | 6 | 1-21 |
| OUDALAN | 7 | 70% | 8 | 4-22 |
| COMOE | 10 | 60% | 9 | 2-18 |
| KOMANDJARI | 11 | 52% | 10 | 2-32 |
| BAM | 12 | 29% | 12 | 7-21 |
| NOUMBIEL | 15 | 26% | 17 | 3-34 |
| KOULPELOGO | 13 | 14% | 13 | 9-16 |
| YATENGA | 18 | 12% | 18 | 9-33 |

Noyau dur (dans le top 10 dans au moins 90 % des tirages) : SENO, TAPOA, YAGHA.
Provinces du top 10 (poids égaux) présentes dans le top 10 dans au moins la moitié des tirages : 10 sur 10.
Conclusion : le choix des poids change l'ordre à l'intérieur du groupe de tête, pas sa composition.

## 3. Résultats dans le découpage de 2025 (17 régions, 47 provinces)
Les 45 anciennes provinces correspondent chacune à une nouvelle, sauf le Soum (Djelgodji, Karo-Peli) et la Tapoa (Dyamongou, Gobnangou), réparties au prorata de la superficie. Ratios et indice : ceux de l'ancienne province.

| Région 2025 | Élèves 2024-2025 | Élèves par maître | Indice moyen | Déficit maîtres 2030 | Enseignants attribués | Salles attribuées |
|---|---|---|---|---|---|---|
| Liptako | 50 892 | 73.0 | 59 | 412 | 400 | 485 |
| Tapoa | 12 213 | 48.1 | 58 | 26 | 25 | 60 |
| Soum | 11 507 | 62.5 | 57 | 64 | 60 | 70 |
| Sirba | 37 882 | 57.7 | 49 | 193 | 180 | 145 |
| Goulmou | 82 645 | 57.5 | 49 | 408 | 375 | 445 |
| Tannounyan | 135 550 | 47.8 | 43 | 326 | 275 | 450 |
| Koulsé | 235 754 | 64.2 | 38 | 1 555 | 1 275 | 1 165 |
| Yaadga | 352 908 | 54.5 | 32 | 1 283 | 830 | 1 410 |
| Sourou | 70 948 | 57.0 | 31 | 293 | 180 | 145 |
| Djôrô | 144 196 | 40.0 | 30 | 0 | 0 | 0 |
| Nakambé | 270 665 | 51.3 | 28 | 703 | 180 | 255 |
| Oubri | 202 566 | 45.3 | 24 | 117 | 0 | 10 |
| Kadiogo | 607 555 | 47.7 | 23 | 1 252 | 0 | 0 |
| Guiriko | 420 861 | 52.9 | 22 | 1 521 | 670 | 595 |
| Bankui | 172 463 | 55.6 | 21 | 664 | 240 | 220 |
| Nando | 344 679 | 49.6 | 19 | 605 | 67 | 80 |
| Nazinon | 154 812 | 44.8 | 15 | 92 | 0 | 0 |

Indice moyen : moyenne des indices provinciaux pondérée par les élèves de 2024-2025.