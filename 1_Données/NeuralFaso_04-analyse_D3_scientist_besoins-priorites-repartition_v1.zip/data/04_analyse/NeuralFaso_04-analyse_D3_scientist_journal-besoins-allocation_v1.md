# Journal de l'étape 4 — besoins 2030, priorités et allocation
Exécuté le 17/11/2026 20:58

## Hypothèses
- `annee_base` = 2024-2025
- `annee_reference` = 2017-2018
- `pop_base` = 2024
- `annee_cible` = 2030
- `rem_cible` = 50
- `eleves_par_salle_cible` = 50
- `rem_qualite` = 40
- `groupes_par_salle` = 1.0
- `tbs_minimum_2030` = 100.0
- `budget_part_deficit` = 0.5
- `poids_equite` = 1.0
- `pas_allocation` = 5

- Contrôle : TBS recalculé 2024-2025, national = 78.7 %.

## Contrôle : quelle population pour l'année scolaire 2024-2025 ?
TBS recalculé (élèves DGESS / population INSD des 6-11 ans) comparé au TBS publié par la DGESS, 13 régions.

| Région | TBS DGESS | pop. 2024 | pop. 2025 | moyenne 2024-2025 |
|---|---|---|---|---|
| BOUCLE DU MOUHOUN | 62.73 | 62.73 | 61.18 | 61.94 |
| CASCADES | 77.51 | 77.51 | 75.02 | 76.25 |
| CENTRE | 115.43 | 115.43 | 111.26 | 113.31 |
| CENTRE-EST | 78.82 | 78.82 | 76.65 | 77.72 |
| CENTRE-NORD | 58.04 | 58.04 | 56.37 | 57.19 |
| CENTRE-OUEST | 100.93 | 100.93 | 98.30 | 99.60 |
| CENTRE-SUD | 100.89 | 100.88 | 98.54 | 99.70 |
| EST | 29.64 | 29.64 | 28.71 | 29.17 |
| HAUTS-BASSINS | 93.11 | 93.11 | 90.37 | 91.72 |
| NORD | 95.89 | 95.89 | 93.32 | 94.59 |
| PLATEAU CENTRAL | 100.94 | 100.94 | 98.34 | 99.62 |
| SAHEL | 27.62 | 27.62 | 26.93 | 27.27 |
| SUD-OUEST | 82.15 | 82.15 | 79.98 | 81.05 |
| **Écart absolu moyen** | — | 0.00 | 2.21 | 1.12 |

Conclusion : la DGESS rapporte l'année scolaire N-(N+1) à la population de l'année N (rentrée d'octobre N). Le projet suit cette convention, et la reprend pour l'horizon : l'année 2030 désigne l'année scolaire 2030-2031.

## Sensibilité : double vacation
En 2024-2025, on compte 1.04 groupe pédagogique par salle au niveau national (de 0.83 à 1.20 selon la province ; 13 provinces au-dessus de 1,05). Hypothèse retenue : 1.0 groupe(s) par salle.

| Scénario | Déficit de salles, hypothèse retenue | Déficit si la pratique de 2024-2025 se maintient | Écart |
|---|---|---|---|
| tendanciel | 11 070 | 8 455 | -2 615 (-24%) |
| rattrapage | 33 525 | 30 339 | -3 186 (-10%) |
| retour | 24 258 | 21 076 | -3 182 (-13%) |

La double vacation réduit le besoin de salles, mais elle raccourcit le temps d'apprentissage. Le PSEF la traite comme une mesure de transition : la norme d'un groupe par salle reste la cible. L'application permet de changer ce paramètre.

- tendanciel  enseignants : budget 4 757 (50% du déficit de 9 514). Élèves au-delà de la norme : 474 849 sans allocation  279 518 au prorata  236 999 optimisé (42 519 de moins). Ratio maximal : 97 au prorata contre 57 optimisé.
- tendanciel  salles : budget 5 535 (50% du déficit de 11 070). Élèves au-delà de la norme : 552 606 sans allocation  316 981 au prorata  275 856 optimisé (41 125 de moins). Ratio maximal : 101 au prorata contre 58 optimisé.
- rattrapage  enseignants : budget 15 872 (50% du déficit de 31 743). Élèves au-delà de la norme : 1 586 243 sans allocation  947 804 au prorata  792 643 optimisé (155 161 de moins). Ratio maximal : 215 au prorata contre 70 optimisé.
- rattrapage  salles : budget 16 762 (50% du déficit de 33 525). Élèves au-delà de la norme : 1 675 299 sans allocation  982 001 au prorata  837 199 optimisé (144 802 de moins). Ratio maximal : 206 au prorata contre 70 optimisé.
- retour  enseignants : budget 11 261 (50% du déficit de 22 522). Élèves au-delà de la norme : 1 125 250 sans allocation  666 462 au prorata  562 200 optimisé (104 262 de moins). Ratio maximal : 190 au prorata contre 64 optimisé.
- retour  salles : budget 12 129 (50% du déficit de 24 258). Élèves au-delà de la norme : 1 212 028 sans allocation  711 698 au prorata  605 578 optimisé (106 120 de moins). Ratio maximal : 196 au prorata contre 65 optimisé.

## Évolution de 2017-2018 à 2024-2025 (annuaires DGESS, public + privé)
National : ecoles 15 756 → 14 276 (-9.4%) ; salles 67 709 → 66 887 (-1.2%) ; maitres 66 082 → 65 019 (-1.6%) ; eleves 3 206 060 → 3 308 096 (+3.2%).
Élèves par maître : 48.5 → 50.9.

Provinces qui ont perdu le plus d'élèves (fermetures d'écoles, insécurité, déplacements) :

| Province | Région | Écoles | Élèves | Maîtres | Indice de priorité |
|---|---|---|---|---|---|
| TAPOA | EST | 349 → 59 (-83%) | 61 654 → 12 213 (-80%) | -79% | 58 (rang 3) |
| SOUM | SAHEL | 390 → 45 (-88%) | 55 224 → 11 507 (-79%) | -87% | 57 (rang 4) |
| YAGHA | SAHEL | 204 → 11 (-95%) | 17 824 → 4 169 (-77%) | -93% | 62 (rang 2) |
| KOMANDJARI | EST | 115 → 13 (-89%) | 11 401 → 3 216 (-72%) | -91% | 45 (rang 11) |
| KOMPIENGA | EST | 76 → 18 (-76%) | 19 343 → 6 089 (-69%) | -80% | 51 (rang 6) |
| SOUROU | BOUCLE DU MOUHOUN | 238 → 97 (-59%) | 48 152 → 17 223 (-64%) | -67% | 36 (rang 16) |
| LOROUM | NORD | 237 → 56 (-76%) | 35 262 → 19 142 (-46%) | -78% | 53 (rang 5) |
| BANWA | BOUCLE DU MOUHOUN | 226 → 97 (-57%) | 50 283 → 28 656 (-43%) | -52% | 28 (rang 24) |
| GNAGNA | EST | 383 → 173 (-55%) | 60 297 → 34 666 (-43%) | -58% | 49 (rang 8) |
| NAMENTENGA | CENTRE-NORD | 349 → 123 (-65%) | 54 545 → 31 647 (-42%) | -60% | 38 (rang 14) |

Corrélation entre la variation des élèves et l'indice de priorité : -0.65. Cette évolution n'entre pas dans l'indice (qui décrit la situation de l'année de base) : elle sert à vérifier que les provinces prioritaires sont bien celles où l'école a reculé.

## Scénario « retour » : retrouver le TBS de 2017-2018
Hypothèse : si la sécurité revient, chaque province retrouve au moins son taux brut de scolarisation de 2017-2018. La population de 6-11 ans de 2017 est estimée à partir des effectifs et des TBS régionaux publiés par la DGESS (population = élèves / TBS), répartie entre provinces selon leur part dans la population de 2020 (premières projections INSD).

Par rapport au scénario tendanciel, 670 304 élèves de plus en 2030, dans 38 provinces. Il faut alors 13 008 enseignants et 13 188 salles de plus.

| Province | TBS 2017-2018 | TBS 2024-2025 | Élèves de plus en 2030 | Enseignants de plus | Salles de plus |
|---|---|---|---|---|---|
| TAPOA | 59 % | 9 % | 81 209 | 1 624 | 1 624 |
| GNAGNA | 52 % | 22 % | 51 690 | 1 034 | 1 034 |
| NAMENTENGA | 65 % | 28 % | 44 802 | 896 | 896 |
| SOUM | 67 % | 16 % | 41 488 | 830 | 830 |
| BAM | 85 % | 50 % | 41 296 | 826 | 826 |
| SOUROU | 90 % | 30 % | 37 696 | 754 | 754 |
| SANMATENGA | 97 % | 80 % | 34 982 | 700 | 700 |
| BANWA | 77 % | 40 % | 28 316 | 566 | 566 |
| LOROUM | 103 % | 45 % | 26 882 | 538 | 538 |
| KOULPELOGO | 74 % | 43 % | 26 599 | 532 | 532 |
| KOSSI | 73 % | 40 % | 25 984 | 519 | 519 |
| YATENGA | 110 % | 97 % | 24 562 | 491 | 491 |

Lecture : ce scénario chiffre ce que coûterait le retour à l'école des enfants qui l'ont quittée à cause de l'insécurité. Il sert à préparer la réouverture, pas à la remplacer.

## Scénario « qualité » : 40 élèves par maître et par salle
La norme nationale (50) sert de référence. Avec une norme de 40, plus exigeante, les besoins deviennent :

| Scénario de scolarisation | Déficit de maîtres (norme 50) | Déficit de maîtres (norme 40) | Déficit de salles (norme 50) | Déficit de salles (norme 40) |
|---|---|---|---|---|
| tendanciel | 9 514 | 26 859 | 11 070 | 28 726 |
| rattrapage | 31 743 | 55 414 | 33 525 | 57 309 |
| retour | 22 522 | 43 610 | 24 258 | 45 481 |

Le classement des provinces ne dépend pas de la norme (l'indice de priorité n'utilise que la situation observée) ; seuls les volumes à recruter et à construire changent. L'application permet de choisir l'une ou l'autre norme.

## Types d'action recommandés
Seuils : {'tbs_securite': 40, 'part_deplaces': 0.1, 'rem': 50, 'eleves_par_salle': 50, 'salles_precaires': 0.25}
- Rouvrir et sécuriser les écoles (10) : GNAGNA, KOMANDJARI, KOMPIENGA, KOSSI, NAMENTENGA, SENO, SOUM, SOUROU, TAPOA, YAGHA
- Renforcer l'accueil des élèves déplacés (21) : BAM, BANWA, GNAGNA, GOURMA, KOMANDJARI, KOMPIENGA, KOSSI, KOULPELOGO, KOURITTENGA, LOROUM, MOUHOUN, NAMENTENGA, OUBRITENGA, OUDALAN, SANMATENGA, SENO, SOUM, SOUROU, TAPOA, YAGHA, YATENGA
- Recruter et affecter des enseignants (27) : BALE, BAM, BANWA, BOULGOU, BOULKIEMDE, COMOE, GNAGNA, GOURMA, HOUET, KOMANDJARI, KOMPIENGA, KOSSI, KOULPELOGO, KOURITTENGA, LOROUM, MOUHOUN, NAHOURI, NAMENTENGA, NAYALA, OUDALAN, SANGUIE, SANMATENGA, SENO, SOUM, TUY, YAGHA, YATENGA
- Construire ou remplacer des salles (32) : BALE, BAM, BANWA, BOULGOU, COMOE, GANZOURGOU, GNAGNA, GOURMA, HOUET, KOMANDJARI, KOMPIENGA, KOSSI, KOULPELOGO, KOURITTENGA, LOROUM, MOUHOUN, NAHOURI, NAMENTENGA, NAYALA, NOUMBIEL, OUDALAN, PASSORE, SANGUIE, SANMATENGA, SENO, SOUM, SOUROU, TAPOA, TUY, YAGHA, YATENGA, ZONDOMA

## Provinces prioritaires (indice de priorité)
- 1. SENO (SAHEL) : 64/100 — 78 élèves/maître, 35% de salles précaires, TBS 34 %
- 2. YAGHA (SAHEL) : 62/100 — 82 élèves/maître, 36% de salles précaires, TBS 12 %
- 3. TAPOA (EST) : 58/100 — 48 élèves/maître, 38% de salles précaires, TBS 9 %
- 4. SOUM (SAHEL) : 57/100 — 62 élèves/maître, 38% de salles précaires, TBS 16 %
- 5. LOROUM (NORD) : 53/100 — 101 élèves/maître, 16% de salles précaires, TBS 45 %
- 6. KOMPIENGA (EST) : 51/100 — 74 élèves/maître, 10% de salles précaires, TBS 22 %
- 7. OUDALAN (SAHEL) : 50/100 — 65 élèves/maître, 30% de salles précaires, TBS 57 %
- 8. GNAGNA (EST) : 49/100 — 58 élèves/maître, 16% de salles précaires, TBS 22 %
- 9. GOURMA (EST) : 48/100 — 56 élèves/maître, 30% de salles précaires, TBS 77 %
- 10. COMOE (CASCADES) : 47/100 — 51 élèves/maître, 28% de salles précaires, TBS 78 %