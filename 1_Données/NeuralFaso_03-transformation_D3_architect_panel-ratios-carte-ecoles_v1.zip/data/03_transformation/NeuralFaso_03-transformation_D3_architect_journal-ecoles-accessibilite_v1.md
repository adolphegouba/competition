# Journal de l'étape 3c — écoles géolocalisées et accessibilité
Exécuté le 17/11/2026 20:58

## Données
- Points OSM « school » : 11 673, regroupés en 4 905 sites d'écoles (les points à moins de 200 m forment un même site : OSM décrit souvent chaque bâtiment). Écoles primaires de l'annuaire 2024-2025 : 14 276. OSM recense donc au plus 34% des écoles, primaire et secondaire mélangés.
- Carrés de 1 km habités : 324 020 ; enfants de 6-11 ans recalés sur l'INSD 2024 : 4 203 855.

## Résultats
- Enfants de 6-11 ans à plus de 5 km d'une école connue : 1 907 492 (45.4%).
- Ce chiffre est fortement surestimé, car OSM est incomplet : l'annuaire (tableau V.5) ne compte que 1 % environ d'élèves à plus de 5 km. Même dans les 6 provinces où la carte est plus complète (au moins 60% des écoles cartographiées, hors provinces à rouvrir d'abord), 75 848 enfants sont à plus de 5 km d'une école connue (15.7%).
- Zones peuplées sans école sur la carte (au moins 150 enfants à plus de 5 km d'une école connue, maille d'environ 5 km) : 138 là où la carte est plus complète, 3 336 là où elle est incomplète ; aucune dans les 10 provinces à rouvrir d'abord.
- Dans ces provinces, OSM recense souvent plus d'écoles que l'annuaire (Tapoa : 279 contre 59) : la carte garde les écoles d'avant la crise, dont beaucoup sont fermées.

| Province | Fiabilité de la carte | Écoles OSM | Écoles (annuaire) | Couverture OSM | Enfants à plus de 5 km | Zones candidates |
|---|---|---|---|---|---|---|
| HOUET | carte incomplète | 157 | 1 116 | 14% | 141 269 (46%) | 305 |
| COMOE | carte incomplète | 91 | 528 | 17% | 93 974 (68%) | 308 |
| BOULGOU | carte incomplète | 120 | 609 | 20% | 81 238 (51%) | 151 |
| GOURMA | carte incomplète | 42 | 253 | 17% | 74 617 (75%) | 206 |
| SANMATENGA | carte incomplète | 175 | 587 | 30% | 72 721 (38%) | 163 |
| BANWA | carte incomplète | 1 | 97 | 1% | 70 431 (99%) | 173 |
| KOULPELOGO | carte incomplète | 20 | 140 | 14% | 58 341 (74%) | 143 |
| TUY | carte incomplète | 9 | 259 | 4% | 56 937 (86%) | 155 |
| GANZOURGOU | carte incomplète | 89 | 501 | 18% | 55 017 (55%) | 88 |
| PONI | carte incomplète | 44 | 365 | 12% | 53 113 (74%) | 165 |
| KENEDOUGOU | carte incomplète | 65 | 347 | 19% | 49 360 (62%) | 150 |
| SISSILI | carte incomplète | 42 | 280 | 15% | 48 792 (69%) | 147 |
| PASSORE | carte incomplète | 35 | 453 | 8% | 48 604 (50%) | 85 |
| BALE | carte incomplète | 19 | 238 | 8% | 45 771 (75%) | 117 |
| MOUHOUN | carte incomplète | 105 | 308 | 34% | 44 310 (55%) | 126 |
| SANGUIE | carte incomplète | 110 | 349 | 32% | 39 687 (50%) | 92 |
| ZOUNDWEOGO | carte incomplète | 22 | 331 | 7% | 39 372 (64%) | 108 |
| BAM | carte incomplète | 66 | 158 | 42% | 37 528 (36%) | 72 |
| KOURITTENGA | carte incomplète | 88 | 394 | 22% | 33 213 (32%) | 53 |
| NAYALA | carte incomplète | 45 | 94 | 48% | 31 812 (70%) | 92 |
| IOBA | carte incomplète | 25 | 253 | 10% | 30 229 (57%) | 75 |
| ZIRO | carte incomplète | 74 | 191 | 39% | 28 519 (56%) | 91 |
| OUBRITENGA | carte incomplète | 68 | 372 | 18% | 23 384 (36%) | 49 |
| BOUGOURIBA | carte incomplète | 17 | 144 | 12% | 20 628 (66%) | 62 |
| NAHOURI | carte incomplète | 51 | 172 | 30% | 19 578 (51%) | 52 |
| NOUMBIEL | carte incomplète | 15 | 115 | 13% | 16 499 (83%) | 44 |
| ZONDOMA | carte incomplète | 55 | 310 | 18% | 13 613 (26%) | 27 |
| LERABA | carte incomplète | 44 | 177 | 25% | 12 880 (34%) | 37 |
| KADIOGO | carte incomplète | 925 | 2 397 | 39% | 569 (0%) | 0 |
| YATENGA | carte plus complète | 457 | 727 | 63% | 29 187 (16%) | 49 |
| OUDALAN | carte plus complète | 55 | 61 | 90% | 22 230 (70%) | 47 |
| BOULKIEMDE | carte plus complète | 469 | 659 | 71% | 14 673 (10%) | 21 |
| BAZEGA | carte plus complète | 318 | 293 | 108% | 5 024 (9%) | 11 |
| KOURWEOGO | carte plus complète | 146 | 213 | 68% | 3 213 (9%) | 7 |
| LOROUM | carte plus complète | 191 | 56 | 341% | 1 521 (4%) | 3 |
| GNAGNA | rouvrir d'abord | 37 | 173 | 21% | 107 469 (69%) | 0 |
| SENO | rouvrir d'abord | 9 | 70 | 13% | 71 172 (84%) | 0 |
| NAMENTENGA | rouvrir d'abord | 84 | 123 | 68% | 56 180 (50%) | 0 |
| TAPOA | rouvrir d'abord | 279 | 59 | 473% | 53 048 (38%) | 0 |
| SOUROU | rouvrir d'abord | 17 | 97 | 18% | 50 540 (88%) | 0 |
| SOUM | rouvrir d'abord | 80 | 45 | 178% | 38 020 (51%) | 0 |
| KOSSI | rouvrir d'abord | 123 | 120 | 102% | 35 225 (49%) | 0 |
| YAGHA | rouvrir d'abord | 3 | 11 | 27% | 33 997 (97%) | 0 |
| KOMPIENGA | rouvrir d'abord | 6 | 18 | 33% | 24 286 (87%) | 0 |
| KOMANDJARI | rouvrir d'abord | 12 | 13 | 92% | 19 703 (81%) | 0 |

## Limites
- OSM est incomplet, surtout en zone rurale et en zone d'insécurité : une zone « loin d'une école connue » peut avoir une école non cartographiée. La colonne « couverture OSM » indique où la carte est la plus fiable.
- WorldPop 2020 ne tient pas compte des déplacements de population liés à l'insécurité.
- L'état des salles (paille, banco) et les fermetures d'écoles ne sont pas publiés école par école : ils sont donnés par province.
- Une zone peuplée sans école sur la carte est une piste à vérifier sur le terrain, pas un site de construction : il peut y exister une école non cartographiée. Avec la carte scolaire géolocalisée du ministère, la même méthode donnerait des sites fiables.