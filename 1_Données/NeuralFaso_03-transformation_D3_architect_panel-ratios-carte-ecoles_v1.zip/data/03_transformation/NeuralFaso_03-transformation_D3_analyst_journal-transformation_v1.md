# Journal de transformation — 17/11/2026 20:58

- Source : `NeuralFaso_02-nettoyage_D3_engineer_dgess-prescolaire-primaire-propres_v1.csv`
- Panel : 280 lignes, 44 variables, cycles ['prescolaire', 'primaire'], années 2015-2016 à 2024-2025.
- Écoles et salles : sommées sur les statuts (public, privé, communautaire).
- Ratios calculés seulement quand le dénominateur est positif.
- `ecoles_perdues` compare chaque année au maximum atteint depuis 2015-2016 : c'est un indicateur indirect des fermetures, pas un décompte officiel.

- prescolaire, 2024-2025 : élèves par école de 66 à 147 (plus forte charge : SAHEL).
- primaire, 2024-2025 : élèves par école de 164 à 334 (plus forte charge : SAHEL).