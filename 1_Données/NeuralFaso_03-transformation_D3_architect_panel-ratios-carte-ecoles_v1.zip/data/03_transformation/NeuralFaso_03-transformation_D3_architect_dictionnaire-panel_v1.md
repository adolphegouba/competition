# Dictionnaire des variables — panel région × année (étape 3)

Source : `NeuralFaso_02-nettoyage_D3_engineer_dgess-prescolaire-primaire-propres_v1.csv` (étape 2). Une ligne = un cycle, une région, une année scolaire. Les lignes NATIONAL sont la somme des 13 régions ; les taux nationaux ne sont pas recalculés.

| Variable | Description | Valeurs manquantes |
|---|---|---|
| `cycle` | Cycle d'enseignement (prescolaire, primaire) | 0 |
| `region` | Région (13 anciennes régions) ou NATIONAL | 0 |
| `annee_scolaire` | Année scolaire AAAA-AAAA | 0 |
| `annee` | Année de début de l'année scolaire (pour les graphiques) | 0 |
| `effectif_T` | Élèves inscrits, total | 0 |
| `effectif_G` | Élèves inscrits, garçons | 0 |
| `effectif_F` | Élèves inscrits, filles | 0 |
| `nouveaux_inscrits_cp1_T` | Nouveaux inscrits au CP1, total | 140 |
| `nouveaux_inscrits_cp1_G` | Nouveaux inscrits au CP1, garçons | 140 |
| `nouveaux_inscrits_cp1_F` | Nouveaux inscrits au CP1, filles | 140 |
| `nb_ecoles` | Nombre d'écoles (ou de structures au préscolaire), tous statuts | 0 |
| `nb_ecoles_public` | Nombre d'écoles publiques | 0 |
| `nb_ecoles_prive` | Nombre d'écoles privées | 0 |
| `nb_salles` | Nombre de salles de classe, tous statuts (disponible au préscolaire) | 140 |
| `nb_salles_public` | Nombre de salles de classe publiques | 140 |
| `tbs_T` | Taux brut de scolarisation, total (%) | 20 |
| `tbs_G` | TBS garçons (%) | 20 |
| `tbs_F` | TBS filles (%) | 20 |
| `tba_T` | Taux brut d'admission, total (%) | 150 |
| `tba_F` | Taux brut d'admission (%), filles | 150 |
| `tba_G` | Taux brut d'admission (%), garçons | 150 |
| `taux_achevement_T` | Taux d'achèvement, total (%) | 150 |
| `taux_achevement_G` | Taux d'achèvement (%), garçons | 150 |
| `taux_achevement_F` | Taux d'achèvement, filles (%) | 150 |
| `taux_reussite_cep_T` | Taux de réussite au CEP, total (%) | 150 |
| `taux_reussite_cep_F` | Taux de réussite au CEP (%), filles | 150 |
| `taux_reussite_cep_G` | Taux de réussite au CEP (%), garçons | 150 |
| `ips_tbs` | Indice de parité filles/garçons du TBS | 20 |
| `ips_tba` | Indice de parité du TBA | 150 |
| `ips_tap` | Indice de parité du taux d'achèvement | 150 |
| `eleves_par_ecole` | Élèves par école (effectif_T / nb_ecoles) | 0 |
| `eleves_par_salle` | Élèves par salle de classe (effectif_T / nb_salles) | 140 |
| `part_filles` | Part des filles dans les effectifs (effectif_F / effectif_T) | 0 |
| `part_ecoles_privees` | Part des écoles privées (nb_ecoles_prive / nb_ecoles) | 0 |
| `ecart_tbs_g_f` | Écart de TBS garçons moins filles (points) | 20 |
| `var_effectif` | Variation des effectifs par rapport à l'année précédente | 28 |
| `var_ecoles` | Variation du nombre d'écoles par rapport à l'année précédente | 28 |
| `ecoles_max_historique` | Nombre maximal d'écoles atteint depuis 2015-2016 | 0 |
| `ecoles_perdues` | Écoles en moins par rapport au maximum historique (fermetures probables) | 0 |
| `taux_ecoles_perdues` | ecoles_perdues / ecoles_max_historique | 0 |
| `eleves_par_ecole_rang` | Rang de la région (1 = plus forte charge par école) pour l'année | 0 |
| `nb_ecoles_communautaire` | Nombre de structures communautaires (préscolaire) | 140 |
| `nb_salles_communautaire` | Nombre de salles de classe communautaires | 140 |
| `nb_salles_prive` | Nombre de salles de classe privées | 140 |